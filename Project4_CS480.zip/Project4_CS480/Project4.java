package aa;


import java.util.*;
import java.io.*;
import java.sql.*;
import org.apache.commons.codec.digest.DigestUtils;
import java.lang.*;
import org.apache.commons.lang3.RandomStringUtils;

public class try2 {

	
	public static void main(String args[]) throws SQLException, ClassNotFoundException
	{
	 
	 

Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/bookstore3";
String username="root";
//String password="Abhi0512";



Connection conn = DriverManager.getConnection(url,"root","");

Statement stmt = conn.createStatement();





// Entering data into users table
System.out.println("How many rows do you want to enter in users table?");

Scanner reader = new Scanner(System.in);  // Reading from System.in

int n = reader.nextInt();


Random rand= new Random();

int i=0;


// Entering data into users table

while(i<=n)
{
	
	String usrname=RandomStringUtils.randomAlphabetic(5);
	String paswrd=RandomStringUtils.randomAlphanumeric(17);
	String name=RandomStringUtils.randomAlphabetic(20);
	String Address=RandomStringUtils.randomAlphanumeric(50);
	String credit=RandomStringUtils.randomNumeric(12);
	int birthyear= rand.nextInt(6001);
	
	
    
	String sqlQuery = "Insert into users(username,Passsword,Namme,address,CreditCard,usertype,userbirthyear) values('"+usrname+"','"+paswrd+"','"+name+"','"+Address+"',"+credit+",'user',"+birthyear+") ";
	stmt.executeUpdate(sqlQuery);
    i++;
    
}
System.out.println(+n+" rows entered in users table\n");

// Entering data into authors table.



System.out.println("How many rows do you want to enter in authors table?");
n=reader.nextInt();

for(i=0;i<=n;i++)
{
String name=RandomStringUtils.randomAlphabetic(25);
int birthyear= rand.nextInt(4001);
String sqlQueryauthor = "Insert into author(author_name,authorbirthyear) values('"+name+"',"+birthyear+") ";
stmt.executeUpdate(sqlQueryauthor);

}

System.out.println(+n+" rows entered in the authors table\n");


// Entering data into Books table

System.out.println("How many rows do you want to enter in Books table?");
n=reader.nextInt();



for(i=0;i<=n;i++)
{
String Title=RandomStringUtils.randomAlphabetic(25);
String Desc=RandomStringUtils.randomAlphabetic(100);
int price=rand.nextInt(500)+10;
int authorid=rand.nextInt(500)+1;
int writtenin= rand.nextInt(4001);
String sqlQueryBooks = "Insert into Books(Title,Description,price,author_id,writtenin) values"
		+ "('"+Title+"','"+Desc+"',"+price+","+authorid+","+writtenin+") ";
stmt.executeUpdate(sqlQueryBooks);

}

System.out.println(+n+" rows entered in the Books table\n");


// Entering data in BooksAndAuthors table

System.out.println("How many rows do you want to enter in BooksAndAuthors table?");
n=reader.nextInt();



for(i=0;i<=n;i++)
{

int ISBN=rand.nextInt(500)+1;
int authorid=rand.nextInt(600)+1;

String sqlQueryBooksandAuthor = "Insert into BooksAndAuthors(ISBN,author_id) values("+ISBN+","+authorid+") ";
stmt.executeUpdate(sqlQueryBooksandAuthor);

}

System.out.println(+n+" rows entered in the BooksAndAuthors table\n");
	
	
// Entering data into Orders table

System.out.println("How many rows do you want to enter in Orders table?");
n=reader.nextInt();



for(i=0;i<=n;i++)
{

int quantity=rand.nextInt(20)+1;
int userid=rand.nextInt(500)+1;
int ISBN= rand.nextInt(590)+1;
String sqlQueryOrders = "Insert into Orders(ISBN,userid,quantity) values"
		+ "("+ISBN+","+userid+","+quantity+") ";
stmt.executeUpdate(sqlQueryOrders);

}

System.out.println(+n+" rows entered in the Orders table\n"); 

// Entering data into Order_History	
	
System.out.println("How many rows do you want to enter in Order History table?");
n=reader.nextInt();



for(i=0;i<=n;i++)
{

int orderid=rand.nextInt(400)+1;
int quantity=rand.nextInt(20)+1;
int userid=rand.nextInt(500)+1;
int ISBN= rand.nextInt(500)+1;

int ISBNtry=1;
int useridtry=1;

long offset = Timestamp.valueOf("1000-01-02 00:00:00").getTime();
long end = Timestamp.valueOf("4000-01-28 00:00:00").getTime();
long diff = end - offset + 1;

Timestamp details = new Timestamp(offset + (long)(Math.random() * diff));

String sqlQueryOrderHistory = "Insert into Order_History(order_id,userid,ISBN,details,quantity) values"
		+ "("+orderid+","+userid+","+ISBN+",'"+details+"',"+quantity+") ";


stmt.executeUpdate(sqlQueryOrderHistory);

}

System.out.println(+n+" rows entered in the Order History table\n");
	






	
	}
}

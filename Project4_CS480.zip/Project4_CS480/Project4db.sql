
/* Database 1 */


create database bookstore1;
use bookstore1;

Create table users
( 
userid int auto_increment null primary key,
username varchar(20) not null,
passsword varchar(100), 
Namme varchar(20),
address varchar(2000), 
CreditCard numeric(16,0),
usertype varchar(20),
userbirthyear int,
constraint userbirthyear_ck check(birthyear between 0 and 6000 )
);


Create table author
( author_id int auto_increment primary key not null,
author_name varchar(50),
authorbirthyear int,
constraint authorbirthyear_ck check(birthyear between 0 and 4000 )
); 



create table books
( ISBN int auto_increment primary key, 
Title varchar(30) ,
Description varchar(200), 
price numeric(5,2) ,
author_id int not null,
writtenin int,
constraint writtenin_ck check(birthyear between 0 and 4000 ),
foreign key (author_id) references author(author_id) on delete cascade on update cascade
);

Create table BooksAndAuthors
( ISBN int,
author_id int not null,
primary key(ISBN,author_id),
foreign key(ISBN) references Books(ISBN),
foreign key(author_id) references author(author_id)
);


create table Orders
( order_id int(11) auto_increment primary key, 
ISBN int, 
userid int, 
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);



create table Order_history
( id int auto_increment primary key,
order_id int,
userid int,
ISBN int,
details datetime,
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);









/*Database 2*/

create database bookstore2;
use bookstore2;

Create table users
( 
userid int auto_increment null primary key,
username varchar(20) not null,
passsword varchar(100), 
Namme varchar(20),
address varchar(2000), 
CreditCard numeric(16,0),
usertype varchar(20),
userbirthyear int,
constraint userbirthyear_ck check(birthyear between 0 and 6000 )
);


Create table author
( author_id int auto_increment primary key not null,
author_name varchar(50),
authorbirthyear int,
constraint authorbirthyear_ck check(birthyear between 0 and 4000 )
); 



create table books
( ISBN int auto_increment primary key, 
Title varchar(30) ,
Description varchar(200), 
price numeric(5,2) ,
author_id int not null,
writtenin int,
constraint writtenin_ck check(birthyear between 0 and 4000 ),
foreign key (author_id) references author(author_id) on delete cascade on update cascade
);

Create table BooksAndAuthors
( ISBN int,
author_id int not null,
primary key(ISBN,author_id),
foreign key(ISBN) references Books(ISBN),
foreign key(author_id) references author(author_id)
);


create table Orders
( order_id int(11) auto_increment primary key, 
ISBN int, 
userid int, 
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);



create table Order_history
( id int auto_increment primary key,
order_id int,
userid int,
ISBN int,
details datetime,
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);











/*Database 3*/

create database bookstore3;
use bookstore3;

Create table users
( 
userid int auto_increment null primary key,
username varchar(20) not null,
passsword varchar(100), 
Namme varchar(20),
address varchar(2000), 
CreditCard numeric(16,0),
usertype varchar(20),
userbirthyear int,
constraint userbirthyear_ck check(birthyear between 0 and 6000 )
);


Create table author
( author_id int auto_increment primary key not null,
author_name varchar(50),
authorbirthyear int,
constraint authorbirthyear_ck check(birthyear between 0 and 4000 )
); 



create table books
( ISBN int auto_increment primary key, 
Title varchar(30) ,
Description varchar(200), 
price numeric(5,2) ,
author_id int not null,
writtenin int,
constraint writtenin_ck check(birthyear between 0 and 4000 ),
foreign key (author_id) references author(author_id) on delete cascade on update cascade
);

Create table BooksAndAuthors
( ISBN int,
author_id int not null,
primary key(ISBN,author_id),
foreign key(ISBN) references Books(ISBN),
foreign key(author_id) references author(author_id)
);


create table Orders
( order_id int(11) auto_increment primary key, 
ISBN int, 
userid int, 
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);



create table Order_history
( id int auto_increment primary key,
order_id int,
userid int,
ISBN int,
details datetime,
quantity int,
foreign key(userid) references users(userid) on delete cascade on update cascade,
foreign key(ISBN) references books(ISBN) on delete cascade on update cascade
);

/*to use B-tree index 

CREATE INDEX orderB USING BTREE ON order_history(details);
CREATE INDEX userB USING BTREE ON users(userbirthyear);
CREATE INDEX authorB USING BTREE ON author(authorbirthyear);
CREATE INDEX booksB USING BTREE ON Books(writtenin,price);
 */

/* To use Hash-indices

CREATE INDEX orderB USING hash ON order_history(details);
CREATE INDEX userB USING hash ON users(userbirthyear);
CREATE INDEX authorB USING hash ON author(authorbirthyear);
CREATE INDEX booksB USING hash ON Books(writtenin,price);
*/

/*Query1

select username from ((users natural join order_history) natural join Books) natural join author
where (writtenin =2016 or writtenin = 3333 or writtenin=1200) and price>50 
and authorbirthyear=1999 and details between '2005-01-01' and '2005-12-31'; 
*/

/*Query2
select* from order_history where id in(Select id from (order_history natural join users) natural join books 
where (details between '0000-01-01' And '3000-12-31') 
and userbirthyear>=15 and userbirthyear<=3000 and writtenin>=2000 and price=15) limit 100000;
*/
